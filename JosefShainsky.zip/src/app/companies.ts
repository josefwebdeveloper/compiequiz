export class Company {
  company: string;
  branche: string;
  lat?: number;
  lng?: number;
  distance?: number;
}
